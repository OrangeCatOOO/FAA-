from fastapi_amis_admin.admin import PageAdmin
from fastapi_amis_admin.amis.components import Page, Alert, Action, ButtonToolbar, Button, Link, Dialog
from db import SessionLocal
from fastapi import Depends
from auth import get_current_user, check_permission


# 获取数据库会话
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class RegisterPage(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    page = Page.parse_obj({
        "type": "page",
        "title": "注册",
        "body": [
            {
                "type": "form",
                "api": {
                    "method": "post",
                    "url": "/register",
                    "adaptor": """
                        if (payload.status === 0) {
                            return {
                                ...payload,
                                status: 0,
                                msg: '注册申请已提交，请等待管理员审核'
                            };
                        }
                        return payload;
                    """
                },
                "controls": [
                    {"type": "input-text", "name": "username", "label": "用户名", "required": True},
                    {"type": "input-password", "name": "password", "label": "密码", "required": True},
                    {"type": "input-text", "name": "department", "label": "所属单位", "required": True}
                ],
                "actions": [
                    {
                        "type": "button",
                        "label": "注册",
                        "actionType": "submit",
                        "level": "primary"
                    }
                ],
                "messages": {
                    "saveSuccess": "注册申请已提交！"
                }
            }
        ]
    })
    page_path = "/register"

class LoginPage(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    page = Page.parse_obj({
        "type": "page",
        "title": "登录页面",
        "body": [
            # 登录表单模块
            {
                "type": "form",
                "api": {
                    "method": "post",
                    "url": "/login",
                    "requestAdaptor": "api.credentials = 'include'; return api;",  
                    "requestAdaptor": "return {\n  ...api,\n  data: {\n    username: api.data.username,\n    password: api.data.password\n  }\n};",
                    "adaptor": """if (payload.message === '登录成功') {
                        // 根据角色跳转
                        if (payload.role === 0) {
                            window.location.href = 'http://127.0.0.1:9000/admin/';
                        } 
                        return { 
                            status: 0, 
                            msg: '登录成功' 
                        };
                    }"""
                },
                "controls": [
                    {"type": "text", "name": "username", "label": "用户名", "required": True},
                    {"type": "password", "name": "password", "label": "密码", "required": True}
                ],
                "actions": [
                    # 主登录按钮
                    {
                        "type": "button",
                        "label": "登录",
                        "actionType": "submit"
                    },
                    # 辅助功能按钮组
                    {
                        "type": "button-toolbar",
                        "buttons": [
                            # 用户信息弹框按钮
                            {
                                "label": "用户信息",
                                "type": "button",
                                "actionType": "dialog",
                                "icon": "fa fa-user",
                                "dialog": {
                                    "title": "用户详情",
                                    "body": {
                                        "type": "service",
                                        "api": "/users/me",
                                        "body": "<p>用户名：${username}</p><p>权限：${role}</p>"
                                    }
                                }
                            },
                            # 跳转按钮
                            {
                                "label": "用户管理跳转",
                                "type": "button",
                                "actionType": "url",
                                "url": "http://127.0.0.1:9000/admin/",
                                "icon": "fa fa-external-link",
                                "className": "btn-success"
                            },
                            {
                                "type": "button",
                                "label": "退出登录",
                                "actionType": "ajax",
                                "api": {
                                    "method": "post",
                                    "url": "/logout",
                                    "adaptor": """if(payload.message === '退出成功') {
                                        window.location.reload();
                                        return { 
                                            status: 0, 
                                            msg: '退出成功，即将跳转...'
                                        };
                                    }"""
                                },
                                "level": "danger",
                                "icon": "fa fa-sign-out"
                            }
                        ]
                    }
                ]
            }
        ]
    })
    page_path = "/login"

class FileManagementPage(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    page = Page.parse_obj({
        "type": "page",
        "title": "文件管理中心",
        "body": [
            
        ]
    })
    page_path = "/file-center"
    page = Page.parse_obj({
        "type": "page",
        "title": "文件管理中心",
        "body": [
            {
                "type": "alert",
                "level": "info",
                "body": "支持上传个人文件和下载样例文件",
                "showIcon": True
            },
            {
                "type": "action",
                "label": "下载excel样例文件",
                "actionType": "download",
                "api": "/amis/api/download",
                "fileName": "sample.xlsx",
                "className": "mb-4"
            },
            {
                "type": "action",
                "label": "下载key样例文件",
                "actionType": "download",
                "api": "/amis/api/download",
                "fileName": "key.txt",
                "className": "mb-4"
            },
            # 上传文件表单（放在uploads表格前）
            {
                "type": "form",
                "api": {
                    "method": "post",
                    "url": "/upload/file",
                    "dataType": "form-data",
                    "adaptor": """if (payload.status === 0) {
                        window.location.reload();
                    } return payload;"""
                },
                "body": [
                    {
                        "type": "input-file",
                        "name": "file",
                        "label": "选择文件",
                        "accept": ".xlsx, .txt",
                        "asBlob": True
                    }
                ],
                "submitText": "上传到uploads目录"
            },
            
            # uploads目录文件表格
            {
                "type": "crud",
                "api": "/files/uploads",
                "syncLocation": False,
                "columns": [
                    {"name": "name", "label": "upload文件名"},
                    {"name": "size", "label": "大小(bytes)", "type": "number"},
                    {"name": "upload_time", "label": "上传时间"},
                    {
                        "type": "operation",
                        "label": "操作",
                        "buttons": [
                            
                            {
                                "type": "button",
                                "label": "路径规划",
                                "actionType": "ajax",
                                "api": {
                                "method": "post",
                                "url": "/process/file/${name}",
                                "adaptor": """ 
                                    if (payload.status === 0) {
                                        window.location.reload();
                                        return {
                                            status: 0
                                        };
                                    }
                                    return payload;
                                """
                            },
                                "confirmText": "确认处理该文件？"
                            },
                            {
                                "type": "button",
                                "label": "删除",
                                "actionType": "ajax",
                                "api": "delete:/files/uploads/${name}",
                                "confirmText": "确认删除？",
                                "className": "text-danger"
                            }
                        ]
                    }
                ]
            },
            
            # results目录文件表格
            {
                "type": "crud",
                "api": "/files/results",
                "syncLocation": False,
                "columns": [
                    {"name": "name", "label": "result文件名"},
                    {"name": "size", "label": "大小(bytes)", "type": "number"},
                    {"name": "upload_time", "label": "生成时间"},
                    {
                        "type": "operation",
                        "label": "操作",
                        "buttons": [
                            {
                                "type": "action",
                                "label": "下载",
                                "actionType": "download",
                                "api": "/download/${name}?category=results",
                                "fileName": "${name}"
                            },
                            {
                                "type": "button",
                                "label": "删除",
                                "actionType": "ajax",
                                "api": "delete:/files/results/${name}",
                                "confirmText": "确认删除？",
                                "className": "text-danger"
                            }
                        ]
                    }
                ]
            }
        ]
    })
    page_path = "/file-center"

class CampusMapPage(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    page_schema = '校园地图导航'  # 菜单显示文字
    page = Page.parse_obj({
  "type": "page",
  "body": {
    "type": "iframe",
    "src": "/show",
    "height": 600,
  },
})

class CompanyRegisterPage(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    page = Page.parse_obj({
        "type": "page",
        "title": "公司注册",
        "body": [
            {
                "type": "form",
                "api": {
                    "method": "post",
                    "url": "/register/company-request",
                    "adaptor": """
                        if (payload.status === 0) {
                            return {
                                ...payload,
                                status: 0,
                                msg: '公司注册申请已提交，请等待审核'
                            };
                        }
                        return payload;
                    """
                },
                "controls": [
                    {
                        "type": "input-text", 
                        "name": "name", 
                        "label": "公司名称",
                        "required": True
                    },
                    {
                        "type": "input-text",
                        "name": "legal_person",
                        "label": "法人代表",
                        "required": True
                    },
                    {
                        "type": "input-text", 
                        "name": "contact_phone", 
                        "label": "联系电话",
                        "required": True
                    }
                ],
                "actions": [
                    {
                        "type": "button",
                        "label": "注册",
                        "actionType": "submit",
                        "level": "primary"
                    }
                ],
                "messages": {
                    "saveSuccess": "公司注册申请已提交！"
                }
            }
        ]
    })
    page_path = "/company-register"

class UserAdmin(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由

    dependencies = [Depends(get_current_user),Depends(check_permission(0))]
    page = Page(
        title="用户管理",
        body=[
             {
                "type": "button-toolbar",
                "buttons": [
                    {
                        "type": "button",
                        "label": "返回管理后台",
                        "actionType": "link",
                        "link": "http://127.0.0.1:8000/admin/#/admin/page/main",
                        "level": "light",
                        "icon": "fa fa-arrow-left"
                    }
                ]
            },
            {
                "type": "form",
                "api": "/register",
                "body": [
                    {"type": "input-text", "name": "username", "label": "用户名", "required": True},
                    {"type": "input-password", "name": "password", "label": "密码", "required": True},
                    {"type": "input-text", "name": "role", "label": "权限", "required": True},
                    {"type": "input-text", "name": "department", "label": "所属单位", "required": True}
                ],
                "title": "添加用户",
                "reload": "page"
            },
            {
            "type": "crud",
            "api": "/users/",
            "syncLocation": False,
            "columns": [
                 {"name": "id", "label": "用户ID"},
                    {
                        "name": "username", 
                        "label": "用户名",
                        "type": "input-text",
                        "editable": True  # 启用行内编辑
                    },
                    {
                        "name": "role", 
                        "label": "权限",
                        "type": "input-text",
                        "editable": True  # 启用行内编辑
                    },
                    {"name": "department", 
                     "label": "所属单位", 
                     "type": "input-text",
                     "editable": True
                     },
                    {
                        "type": "operation",
                        "label": "操作",
                        "buttons": [
                            {
                                "label": "保存",
                                "type": "button",
                                "actionType": "ajax",
                                "api": "put:/users/${id}",
                                "confirmText": "确定要保存修改吗？",
                                "messages": {
                                    "saveSuccess": "修改保存成功",
                                    "saveFailed": "修改保存失败"
                                }
                            },
                        {
                            "type": "button",
                            "label": "删除此用户",
                            "actionType": "ajax",
                            "api": "delete:/users/${id}",
                            "confirmText": "确认删除该用户？",
                            "className": "text-danger"
                        }
                    ]
                }
            ]
            },
            {
                "label": "当前用户",
                "type": "button",
                "actionType": "dialog",
                "icon": "fa fa-plus",
                "dialog": {
                    "title": "登录状态详情",
                    "body": [
                        {
                            "type": "service",
                            "api": {
                                "method": "get",
                                "url": "/users/me",
                                "adaptor": "return { ...payload, cookie_status: '已登录' }"
                            },
                            "body": [
                                {
                                    "type": "tpl",
                                    "tpl": "<p>用户名：${username}</p><p>权限：${role}</p><p>Cookie状态：${cookie_status}</p>"
                                },
                                {
                                    "type": "alert",
                                    "level": "info",
                                    "body": "调试信息：Cookie已通过HttpOnly安全设置，前端无法直接读取具体内容"
                                }
                            ]
                        }
                    ]
                }
            }
        ]
    )
    page_path = "/users"

class RegistrationReviewAdmin(PageAdmin):
    group = None  # 隐藏菜单显示
    page_path = None  # 禁用独立路由


    page = Page.parse_obj({
        "type": "page",
        "title": "注册审核中心",
        "body": [
            {
                "type": "button-toolbar",
                "buttons": [
                    {
                        "type": "button",
                        "label": "返回管理后台",
                        "actionType": "link",
                        "link": "http://127.0.0.1:8000/admin/#/admin/page/main",
                        "level": "light",
                        "icon": "fa fa-arrow-left"
                    }
                ]
            },
            {
                "type": "tabs",
                "tabs": [
                    {
                        "title": "用户注册审核",
                        "body": {
                            "type": "crud",
                            "api": "/admin/registration-requests",
                            "columns": [
                                {"name": "id", "label": "申请ID"},
                                {"name": "username", "label": "用户名"},
                                {"name": "department", "label": "所属单位"},
                                {
                                    "type": "operation",
                                    "label": "操作",
                                    "buttons": [
                                        {
                                            "type": "button",
                                            "label": "通过",
                                            "actionType": "ajax",
                                            "api": "put:/admin/registration-requests/${id}/approve",
                                            "confirmText": "确认通过该用户注册申请？",
                                            "messages": {
                                                "saveSuccess": "用户注册已通过",
                                                "saveFailed": "操作失败"
                                            }
                                        },
                                        {
                                            "type": "button",
                                            "label": "拒绝",
                                            "actionType": "ajax",
                                            "api": "delete:/admin/registration-requests/${id}",
                                            "confirmText": "确认拒绝该用户注册申请？",
                                            "className": "text-danger"
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        "title": "公司注册审核",
                        "body": {
                            "type": "crud",
                            "api": "/admin/company-requests",
                            "columns": [
                                {"name": "id", "label": "申请ID"},
                                {"name": "name", "label": "公司名称"},
                                {"name": "legal_person", "label": "法人代表"},
                                {"name": "contact_phone", "label": "联系电话"},
                                {
                                    "type": "operation",
                                    "label": "操作",
                                    "buttons": [
                                        {
                                            "type": "button",
                                            "label": "通过",
                                            "actionType": "ajax",
                                            "api": "put:/admin/company-requests/${id}/approve",
                                            "confirmText": "确认通过该公司注册申请？",
                                            "messages": {
                                                "saveSuccess": "公司注册已通过",
                                                "saveFailed": "操作失败"
                                            }
                                        },
                                        {
                                            "type": "button",
                                            "label": "拒绝",
                                            "actionType": "ajax",
                                            "api": "delete:/admin/company-requests/${id}",
                                            "confirmText": "确认拒绝该公司注册申请？",
                                            "className": "text-danger"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    })

class 路径规划系统(PageAdmin):
    page = Page.parse_obj({
        "type": "page",
        "title": "综合管理系统",
        "body": [
            {
                "type": "tabs",
                "tabsMode": "chrome",
                "tabs": [
                    {
                        "title": "公司注册",
                        "tab": CompanyRegisterPage.page.dict(by_alias=True)["body"][0]
                    },
                    {
                        "title": "用户注册",
                        "tab": RegisterPage.page.dict(by_alias=True)["body"][0]
                    },
                    {
                        "title": "用户登录",
                        "tab": LoginPage.page.dict(by_alias=True)["body"][0]
                    },
                    {
                        "title": "文件中心",
                        "tab": [c.dict(by_alias=True) for c in FileManagementPage.page.body[1:]]
                    },
                    {
                        "title": "校园地图",
                        "tab": CampusMapPage.page.dict(by_alias=True)["body"]
                    }
                ]
            }
        ]
    })
    page_path = "/main"

class 管理员页面(PageAdmin):

    page = Page.parse_obj({
        "type": "page",
        "title": "综合管理系统",
        "body": [
            {
                "type": "tabs",
                "tabsMode": "chrome",
                "tabs": [
                    {
                        "title": "用户管理",
                        "tab": UserAdmin.page.dict(by_alias=True)["body"]
                    },
                    {
                        "title": "注册审核中心", 
                        "tab": RegistrationReviewAdmin.page.dict(by_alias=True)["body"]
                    }
                ]
            }
        ]
    })
    page_path = "/admin"
