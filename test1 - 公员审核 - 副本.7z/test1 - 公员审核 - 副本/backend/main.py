from fastapi import FastAPI, APIRouter
from fastapi_amis_admin import admin
from fastapi_amis_admin.admin import AdminSite
from fastapi_amis_admin.admin.settings import Settings
from fastapi.middleware.cors import CORSMiddleware
from auth import router as auth_router
from db import init_db, DATABASE_URL
from admin_pages import 路径规划系统, UserAdmin, RegistrationReviewAdmin, 管理员页面
import logging
import uvicorn
from multiprocessing import Process

# 创建全局应用实例（重要！）
app = FastAPI()

# 公共配置
def configure_app(app: FastAPI):
    app.include_router(auth_router)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

def run_main_app():
    # 主系统配置
    main_app = FastAPI()
    configure_app(main_app)
    
    # 主系统Admin配置
    main_site = AdminSite(settings=Settings(
        database_url=DATABASE_URL
    ))
    
    # 取消默认首页
    main_site.unregister_admin(admin.HomeAdmin)

    main_site.register_admin(路径规划系统)
    main_site.mount_app(main_app)
    
    @main_app.on_event("startup")
    async def startup():
        init_db()
    
    uvicorn.run(main_app, host="0.0.0.0", port=8000)

def run_user_admin():
    # 用户管理系统
    user_app = FastAPI()
    configure_app(user_app)
    
    # 用户管理Admin配置
    user_site = AdminSite(settings=Settings(
        database_url=DATABASE_URL
    ))
    user_site.register_admin(管理员页面)
    user_site.mount_app(user_app)
    
    uvicorn.run(user_app, host="0.0.0.0", port=9000)

# 保留原有启动逻辑
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    Process(target=run_main_app).start()
    Process(target=run_user_admin).start()