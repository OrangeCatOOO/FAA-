from fastapi_amis_admin.admin import PageAdmin
from fastapi_amis_admin.amis.components import Page
from fastapi import Depends
from auth import get_current_user, check_permission
from pathlib import Path
import json

# class 路径规划系统(PageAdmin):
#     def __init__(self, admin):
#         super().__init__(admin)
#         menu_path = Path(__file__).parent.parent / "config" / "menu" / "admin_menu.json"
        
#         # 确保目录存在并创建默认配置
#         menu_path.parent.mkdir(parents=True, exist_ok=True)
#         if not menu_path.exists():
#             default_config = {
#                 "type": "page",
#                 "title": "用户服务系统",
#                 "body": []
#             }
#             with open(menu_path, "w", encoding="utf-8") as f:
#                 json.dump(default_config, f, ensure_ascii=False)
        
#         # 读取配置
#         with open(menu_path, "r", encoding="utf-8") as f:
#             self._menu_config = json.load(f)

#     @property
#     def page(self):
#         return Page.parse_obj(self._menu_config)
    
#     page_path = "/main"

# class 管理员系统(PageAdmin):
#     dependencies = [Depends(get_current_user), Depends(check_permission(0))]

#     def __init__(self, admin):
#         super().__init__(admin)
#         menu_path = Path(__file__).parent.parent / "config" / "menu" / "root_menu.json"
        
#         # 确保目录存在并创建默认配置
#         menu_path.parent.mkdir(parents=True, exist_ok=True)
#         if not menu_path.exists():
#             default_config = {
#                 "type": "page",
#                 "title": "管理系统",
#                 "body": []
#             }
#             with open(menu_path, "w", encoding="utf-8") as f:
#                 json.dump(default_config, f, ensure_ascii=False)
        
#         # 读取配置
#         with open(menu_path, "r", encoding="utf-8") as f:
#             self._menu_config = json.load(f)

#     @property
#     def page(self):
#         return Page.parse_obj(self._menu_config)
    
#     page_path = "/admin-main"


class RegisterPage(PageAdmin):

    
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "user_register.json"
        
        # 加载JSON配置
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)
    page_path = "/register"

class LoginPage(PageAdmin):

    
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "user_login.json"
        
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)
    
    page_path = "/login"

class FileManagementPage(PageAdmin):
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "file_management.json"
        
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)
    page_path = "/file-center"

class CampusMapPage(PageAdmin):
    page_schema = '校园地图导航'  # 菜单显示文字
    
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "campus_map.json"
        
        # 加载JSON配置
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)

class CompanyRegisterPage(PageAdmin):
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "company_register.json"
        
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)
    page_path = "/company-register"

class UserAdmin(PageAdmin):
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "user_admin.json"
        
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)
    page_path = "/users"

class RegistrationReviewAdmin(PageAdmin):
    def __init__(self, admin):
        super().__init__(admin)
        config_path = Path(__file__).parent.parent / "backend" / "config" / "pages" / "registration_review.json"
        
        with open(config_path, "r", encoding="utf-8") as f:
            self._page_config = json.load(f)

    @property
    def page(self):
        return Page.parse_obj(self._page_config)





# class 路径规划系统(PageAdmin):
#     page = Page.parse_obj({
#         "type": "page",
#         "title": "综合管理系统",
#         "body": [
#             {
#                 "type": "tabs",
#                 "tabsMode": "chrome",
#                 "tabs": [
#                     {
#                         "title": "公司注册",
#                         "tab": CompanyRegisterPage.page.dict(by_alias=True)["body"][0]
#                     },
#                     {
#                         "title": "用户注册",
#                         "tab": RegisterPage.page.dict(by_alias=True)["body"][0]
#                     },
#                     {
#                         "title": "用户登录",
#                         "tab": LoginPage.page.dict(by_alias=True)["body"][0]
#                     },
#                     {
#                         "title": "文件中心",
#                         "tab": [c.dict(by_alias=True) for c in FileManagementPage.page.body[1:]]
#                     },
#                     {
#                         "title": "校园地图",
#                         "tab": CampusMapPage.page.dict(by_alias=True)["body"]
#                     }
#                 ]
#             }
#         ]
#     })
#     page_path = "/main"

# class 管理员页面(PageAdmin):

#     page = Page.parse_obj({
#         "type": "page",
#         "title": "综合管理系统",
#         "body": [
#             {
#                 "type": "tabs",
#                 "tabsMode": "chrome",
#                 "tabs": [
#                     {
#                         "title": "用户管理",
#                         "tab": UserAdmin.page.dict(by_alias=True)["body"]
#                     },
#                     {
#                         "title": "注册审核中心", 
#                         "tab": RegistrationReviewAdmin.page.dict(by_alias=True)["body"]
#                     }
#                 ]
#             }
#         ]
#     })
#     page_path = "/admin"
