from fastapi import FastAPI
from fastapi_amis_admin import admin
from fastapi_amis_admin.admin import AdminSite
from fastapi_amis_admin.admin.settings import Settings
from fastapi.middleware.cors import CORSMiddleware
from auth import router as auth_router
from db import init_db, DATABASE_URL
from importlib import import_module
from pathlib import Path
import json
import logging
import uvicorn
from multiprocessing import Process
from fastapi import Depends
from auth import check_permission
from admin_pages import CompanyRegisterPage, RegisterPage,LoginPage,FileManagementPage,CampusMapPage, UserAdmin, RegistrationReviewAdmin

app = FastAPI()

def configure_app(app: FastAPI):
    app.include_router(auth_router)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

def load_pages(config_path: str) -> list:
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
    return config["pages"]

def register_pages(site: AdminSite, pages_config: list):
    for page_config in pages_config:
        module = import_module(page_config["module"])
        page_class = getattr(module, page_config["class"])
        
        # 动态创建带权限控制的类
        dependencies = []
        if page_config.get("permission") is not None:
            dependencies.append(Depends(check_permission()))
        
        DynamicClass = type(
            page_config["class"],
            (page_class,),
            {"dependencies": dependencies}
        )
        site.register_admin(DynamicClass)

def create_admin_app(config_name: str, port: int):
    admin_app = FastAPI()
    configure_app(admin_app)
    
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    site.unregister_admin(admin.HomeAdmin)
    
    # 加载对应配置
    config_path = Path(__file__).parent / "config" / "menu" / f"{config_name}_config.json"
    pages_config = load_pages(config_path)
    register_pages(site, pages_config)
    
    site.mount_app(admin_app)
    
    @admin_app.on_event("startup")
    async def startup():
        init_db()
    
    uvicorn.run(admin_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    # 启动主系统（端口8000）
    Process(target=create_admin_app, args=("main", 8000)).start()
    # 启动管理系统（端口9000） 
    Process(target=create_admin_app, args=("root", 9000)).start()
