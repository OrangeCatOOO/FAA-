from fastapi import APIRouter
from fastapi.responses import FileResponse
import os

router = APIRouter()

EXCEL_FILE_PATH = "files/sample.xlsx"

@router.get("/download/excel")
def download_excel():
    """提供 Excel 文件下载"""
    if os.path.exists(EXCEL_FILE_PATH):
        return FileResponse(EXCEL_FILE_PATH, filename="download.xlsx", media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    return {"error": "文件不存在"}
