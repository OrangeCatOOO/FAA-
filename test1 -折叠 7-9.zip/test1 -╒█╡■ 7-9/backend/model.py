from pydantic import BaseModel, Field
from typing import Optional
import re
from datetime import datetime


# 用户相关模型保持不变...
class UserLogin(BaseModel):
    username: str
    password: str

class UserCreate(BaseModel):
    username: str
    password: str
    role: int = 1
    department: str 

class UserUpdate(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    role: Optional[int] = None
    department: Optional[str] = None


class CompanyCreate(BaseModel):
    name: str
    legal_person: str 
    contact_phone: str


class Company(BaseModel):
    name: str
    legal_person: str 
    contact_phone: str


class RegistrationRequestInDB(BaseModel):
    username: str
    password: str
    department: str
    create_time: datetime = Field(default_factory=datetime.utcnow)


class CompanyRegistrationRequest(BaseModel):
    name: str
    legal_person: str 
    contact_phone: str
    create_time: datetime = Field(default_factory=datetime.utcnow)