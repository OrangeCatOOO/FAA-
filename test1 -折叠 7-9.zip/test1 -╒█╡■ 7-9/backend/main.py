from fastapi import FastAPI, Depends
from fastapi_amis_admin import admin
from fastapi_amis_admin.admin import AdminSite, PageAdmin, AdminApp
from fastapi_amis_admin.admin.settings import Settings
from fastapi_amis_admin.amis.components import Page, PageSchema
from fastapi.middleware.cors import CORSMiddleware
from auth import router as auth_router, check_permission
from db import init_db, DATABASE_URL
from pathlib import Path
import json
import logging
import uvicorn
import requests
from multiprocessing import Process
from typing import List, Dict

app = FastAPI()

def configure_app(app: FastAPI):
    app.include_router(auth_router)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

def create_page_admin(config_file: str, page_path: str = None, page_schema: str = None):
    class DynamicPageAdmin(PageAdmin):
        def __init__(self, admin: AdminSite):
            super().__init__(admin)
            config_path = Path(__file__).parent / "config" / "pages" / f"{config_file}.json"
            with open(config_path, "r", encoding="utf-8") as f:
                self._page_config = json.load(f)
        
        @property
        def page(self):
            return Page.parse_obj(self._page_config)

    if page_path:
        DynamicPageAdmin.page_path = page_path
    if page_schema:
        DynamicPageAdmin.page_schema = page_schema
    
    return DynamicPageAdmin

def load_pages(config_path: str) -> list:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)["pages"]

def load_external_systems(config_name: str) -> List[Dict]:
    config_file = "external_system.json" if config_name == "main" else "nav_config.json"
    config_path = Path(__file__).parent / "config" / "menu" / config_file
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"加载系统配置失败: {str(e)}")
        return []

def get_dynamic_schema(system_config: Dict) -> Dict:
    try:
        # 添加本地请求处理逻辑
        if system_config["server_url"].startswith("/"):
            with open(Path(__file__).parent / "config" / "pages" / "company_register.json") as f:
                return json.load(f)
        else:
            response = requests.get(system_config["server_url"], timeout=5)
            return response.json()
    except Exception as e:
        logging.error(f"获取外部系统schema失败: {system_config['name']}, 错误: {str(e)}")
        return {
            "type": "page",
            "title": system_config["name"],
            "body": {
                "type": "alert",
                "level": "danger",
                "body": f"无法连接系统: {system_config['server_url']}"
            }
        }

def register_pages(site: AdminSite, pages_config: list):
    for page_config in pages_config:
        page_class = create_page_admin(
            config_file=page_config["config_file"],
            page_path=page_config.get("page_path"),
            page_schema=page_config.get("page_schema")
        )
        
        dependencies = []
        if page_config.get("permission") is not None:
            dependencies.append(Depends(check_permission))
        
        site.register_admin(
            type(
                f"{page_config['config_file']}Admin",
                (page_class,),
                {"dependencies": dependencies}
            )
        )

def register_external_pages(site: AdminSite, config_name: str):
    systems = load_external_systems( config_name)

    
    def create_child_page(child_config, parent_name, index):
        class ChildPage(PageAdmin):
            page_schema = child_config['name']
            page_path = f"/external/{parent_name.lower()}_{index}"
            
            def __init__(self, admin):
                super().__init__(admin)
                self._config = child_config
            
            @property
            def page(self):
                try:
                    if self._config.get("path"):
                        # 修正路径拼接逻辑
                        config_path = (
                            Path(__file__).parent 
                            / "config" 
                            / "pages" 
                            / f"{self._config['path']}.json"  # 确保带.json后缀
                        )
                        with open(config_path, "r", encoding="utf-8") as f:
                            return Page.parse_obj(json.load(f))
                    # 保留外部系统支持
                    elif self._config.get("server_url"):
                        return Page.parse_obj(get_dynamic_schema(self._config))
                except Exception as e:
                    logging.error(f"页面加载失败: {str(e)}")
                    return Page.parse_obj({
                        "type": "page",
                        "body": f"加载失败: {str(e)}"
                    })
        
        ChildPage.__name__ = f"ChildPage_{parent_name}_{index}"
        return ChildPage

    for system in systems:
        if "children" in system:
            class ParentPage(AdminApp):
                page_schema = PageSchema(label=system['name'], icon="fa fa-folder")
                
                def __init__(self, app):
                    super().__init__(app)
                    for idx, child in enumerate(system["children"]):
                        self.register_admin(create_child_page(child, system['name'], idx))
            
            site.register_admin(ParentPage)
        else:
            page_class = create_child_page(system, "external", 0)
            site.register_admin(page_class)


def register_nav_menu(site: AdminSite):
    """管理员系统折叠菜单实现"""
    systems = load_external_systems("nav")
    
    def create_child_page(child_config, parent_name, index):
        class ChildPage(PageAdmin):
            page_schema = child_config['name']
            page_path = f"/admin/{parent_name.lower()}_{index}"
            
            def __init__(self, admin):
                super().__init__(admin)
                self._config = child_config
            
            @property
            def page(self):
                try:
                    if self._config.get("path"):
                        config_path = (
                            Path(__file__).parent 
                            / "config" 
                            / "pages" 
                            / f"{self._config['path']}.json"
                        )
                        with open(config_path, "r", encoding="utf-8") as f:
                            return Page.parse_obj(json.load(f))
                except Exception as e:
                    logging.error(f"管理员页面加载失败: {str(e)}")
                    return Page.parse_obj({
                        "type": "page",
                        "body": f"加载失败: {str(e)}"
                    })
        
        ChildPage.__name__ = f"AdminChildPage_{parent_name}_{index}"
        return ChildPage

    # 注册带折叠的菜单系统
    for system in systems:
        if "children" in system:
            class ParentAdminApp(AdminApp):  # 使用AdminApp实现折叠菜单
                page_schema = PageSchema(label=system['name'], icon="fa fa-folder")
                
                def __init__(self, app: AdminSite):
                    super().__init__(app)
                    # 注册子页面到当前分组
                    for idx, child in enumerate(system["children"]):
                        self.register_admin(create_child_page(child, system['name'], idx))
            
            site.register_admin(ParentAdminApp)


def create_admin_app(config_name: str, port: int):
    admin_app = FastAPI()
    configure_app(admin_app)
    
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    
    config_path = Path(__file__).parent / "config" / "menu" / f"{config_name}_config.json"
    pages_config = load_pages(config_path)
    register_pages(site, pages_config)
    
    # 注册对应系统的页面
    if config_name == "main":
        register_external_pages(site, config_name)  # 普通用户系统
    else:
        register_nav_menu(site)  # 管理员系统
    
    site.mount_app(admin_app)
    
    @admin_app.on_event("startup")
    async def startup():
        init_db()
    
    uvicorn.run(admin_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    Process(target=create_admin_app, args=("main", 8000)).start()
    Process(target=create_admin_app, args=("root", 9000)).start()