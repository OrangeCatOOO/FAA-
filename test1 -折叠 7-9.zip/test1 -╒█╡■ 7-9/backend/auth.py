from fastapi import APIRouter, Depends, HTTPException, status, Request, Response, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, RedirectResponse
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import jwt, uuid
from db import User, SessionLocal, Company, RegistrationRequest, CompanyRegistrationRequest
from model import UserLogin, UserCreate, UserUpdate, CompanyCreate, RegistrationRequestInDB
from model import CompanyRegistrationRequest as CompanyRegistrationRequestModel
from pathlib import Path
from Path_Planning import NavigationProcessor
from passlib.context import CryptContext
from typing import List, Tuple, Optional 
import pandas as pd
import json
import re

# 创建路由实例
router = APIRouter()

# JWT 配置
SECRET_KEY = "5fQZ9mKd8LJx7vY2pT1wGcRnB3aX6hS4qWzEoP0yNjM"  # 替换为您的密钥
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30  # Token 有效期（分钟）

# OAuth2 密码模式
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# 在注册和登录路由中添加密码哈希,初始化密码上下文
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_password_hash(password: str):
    return pwd_context.hash(password)

# 获取数据库会话
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()




# 从Cookie获取token的依赖项
async def get_token_from_cookie(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="需要重新登录",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return token

# 创建访问令牌
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# 获取当前用户
async def get_current_user(
    token: str = Depends(get_token_from_cookie),
    db: Session = Depends(get_db)
):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="需要重新登录",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if not username:
            raise credentials_exception
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="登录已过期")
    except jwt.InvalidTokenError:
        raise credentials_exception

    user = db.query(User).filter(User.username == username).first()
    return user or credentials_exception


# 菜单配置函数（新增权限字典）
def load_menu_config():
    config_dir = Path(__file__).parent / "config" / "menu"
    permission_map = {}
    
    # 加载所有配置文件
    for config_file in ["main_config.json", "root_config.json"]:
        config_path = config_dir / config_file
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                for page in json.load(f)["pages"]:
                    # 建立页面名称与权限的映射
                    if "page_schema" in page and "permission" in page:
                        permission_map[page["page_schema"]] = page["permission"]
    return permission_map


# 统一权限检查函数
def check_permission():
    def verify_permission(
        request: Request,
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
    ):
        # 获取当前访问的页面名称
        current_page = request.query_params.get("_page", "未知页面")
        
        menu_config = load_menu_config()
        required_role = menu_config.get(current_page, 0)  # 默认权限为0
        
        print(f"正在检查页面权限：{current_page} 所需权限: {required_role} 当前权限: {current_user.role}")
        
        if current_user.role != required_role:
            raise HTTPException(
                status_code=403,
                detail=f"访问 [{current_page}] 需要权限等级 {required_role}（当前权限：{current_user.role}）"
            )
        return current_user
    
    return verify_permission


# 获取key工具函数
def get_user_key(current_user: User):
    """获取用户密钥的通用方法"""
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / current_user.department / current_user.username  / "uploads"
    key_file = user_dir / "key.txt"
    
    if not key_file.exists():
        raise HTTPException(status_code=404, detail="未找到密钥文件 key.txt")
        
    with open(key_file, "r") as f:
        keys = f.read().strip().split(',')
        if not keys:
            raise HTTPException(status_code=400, detail="密钥文件格式错误")
            
    return keys



########################################函数和路由分割线#####################################

#获取key路由
@router.get("/get_ak")
async def get_ak(
    current_user: User = Depends(get_current_user)
):
    try:
        keys = get_user_key(current_user)
        return {"status": 0, "ak": keys[0]}
    except HTTPException as e:
        return {"status": 1, "msg": e.detail}


# 登录路由
@router.post("/login")
async def login(
    response: Response,
    user_data: UserLogin, 
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.username == user_data.username).first()
    
    # 增强验证逻辑
    if not user or not pwd_context.verify(user_data.password, user.password):
        raise HTTPException(
            status_code=401,
            detail="用户名或密码错误",
            headers={"WWW-Authenticate": "Bearer"}
        )

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=access_token_expires
    )
    
    # 添加cookie设置（已存在但需要确认参数）
    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=access_token_expires.seconds,
        httponly=True,
        samesite="Lax",
        secure=False  # 开发环境可关闭，生产环境应启用HTTPS
    )

    return {
        "message": "登录成功",
        "username": user.username,
        "role": user.role,
        }


# 退出登录路由
@router.post("/logout")
def user_logout(
    response: Response
):
    # 清除浏览器中的access_token cookie
    response.delete_cookie(
        key="access_token",
        httponly=True,
        samesite="Lax"
    )
    return {"message": "退出成功"}

# 用户注册路由
@router.post("/register")
async def register(
    request: RegistrationRequestInDB, 
    db: Session = Depends(get_db)
):
    try:
        # 双重检查用户名（用户表和审核表）
        existing_user = db.query(User).filter(User.username == request.username).first()
        existing_request = db.query(RegistrationRequest).filter(RegistrationRequest.username == request.username).first()
        
        if existing_user or existing_request:
            return {
                "status": 1,
                "msg": "用户名不可用",
                "detail": "该用户名已被注册或正在审核中"
            }

        # 创建审核记录
        new_request = RegistrationRequest(
            username=request.username,
            password=get_password_hash(request.password),
            department=request.department
        )
        db.add(new_request)
        db.commit()
        
        return {
            "status": 0,
            "msg": "注册申请已提交",
            "data": {
                "username": request.username,
                "department": request.department,
                "password_hash": new_request.password
            }
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={
                "status": 2,
                "msg": "注册请求提交失败",
                "data": {
                    "error": f"{type(e).__name__}: {str(e)[:100]}",
                    "solution": "请检查用户名是否重复或联系管理员"
                }
            }
        )
    

# 示例文件下载路由
@router.get("/amis/api/download")
async def download_sample_file(
    current_admin: User = Depends(check_permission())
):
    return FileResponse(
        path="static/files/sample.xlsx",  # 确保文件路径正确
        filename="sample.xlsx",
        headers={"Content-Disposition": "attachment"}
    )


# 文件上传路由
@router.post("/upload/file")
async def upload_file(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    try:
        base_dir = Path(__file__).parent / "static/admin"
        user_dir = base_dir / current_user.department / current_user.username
        upload_dir = user_dir / "uploads"
        
        # 确保上传目录存在
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # 生成安全文件名
        filename = file.filename.replace("/", "_").replace("\\", "_")
        file_path = upload_dir / filename
        
        # 保存文件
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
            
        return {
            "status": 0,
            "msg": "文件上传成功",
            "data": {
                "fileName": filename,
                "fileSize": len(content),
                "uploadTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        }
        
    except Exception as e:
        return {
            "status": 1,
            "msg": f"文件上传失败: {str(e)}",
            "data": {}
        }


# 上传文件列表路由
@router.get("/files/uploads")
async def list_uploads(
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    base_dir = Path(__file__).parent / "static/admin"
    target_dir = base_dir / current_user.department / current_user.username / "uploads"
    
    if not target_dir.exists():
        return {"items": [], "total": 0}

    files = []
    for f in target_dir.iterdir():
        if f.is_file():
            stats = f.stat()
            files.append({
                "name": f.name,
                "size": stats.st_size,
                "upload_time": datetime.fromtimestamp(stats.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "path": str(f.relative_to(base_dir))
            })
    
    return {"items": files, "total": len(files)}

# 结果文件列表路由
@router.get("/files/results")
async def list_results(
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    base_dir = Path(__file__).parent / "static/admin"
    target_dir = base_dir / current_user.department / current_user.username / "results"
    
    if not target_dir.exists():
        return {"items": [], "total": 0}

    files = []
    for f in target_dir.iterdir():
        if f.is_file():
            stats = f.stat()
            files.append({
                "name": f.name,
                "size": stats.st_size,
                "upload_time": datetime.fromtimestamp(stats.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "path": str(f.relative_to(base_dir))
            })
    
    return {"items": files, "total": len(files)}


# 上传文件删除路由
@router.delete("/files/uploads/{filename}")
async def delete_file(
    filename: str,
    current_user: User = Depends(get_current_user)
):
    # 构建基础路径
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / current_user.department / current_user.username / "uploads"
    target_file = user_dir / filename
    
    if not target_file.exists():
        raise HTTPException(404, "文件不存在")
    
    try:
        target_file.unlink()
        return {"message": "文件删除成功"}
    except Exception as e:
        raise HTTPException(500, f"删除失败: {str(e)}")


# 结果文件删除路由
@router.delete("/files/results/{filename}")
async def delete_file(
    filename: str,
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    # 构建基础路径
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / current_user.department / current_user.username / "results"
    target_file = user_dir / filename
    
    if not target_file.exists():
        raise HTTPException(404, "文件不存在")
    
    try:
        target_file.unlink()
        return {"message": "文件删除成功"}
    except Exception as e:
        raise HTTPException(500, f"删除失败: {str(e)}")


# 文件路径规划路由
@router.post("/process/file/{filename}")
async def process_file(
    filename: str,
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    try:
        keys = get_user_key(current_user) 

        # 获取文件路径
        base_dir = Path(__file__).parent / "static/admin"
        user_dir = base_dir / current_user.department / current_user.username
        file_path = user_dir / "uploads" / filename
        
        processor = NavigationProcessor(keys)
        processor.process_excel(
            file_path=str(file_path)

        )
        
        return {"status": 0, "msg": "路径规划完成", "data": {"resultFile": filename}}
        
    except Exception as e:
        return {"status": 1, "msg": f"处理失败: {str(e)}"}


# 用户文件下载路由
@router.get("/download/{filename}")
async def download_file(
    filename: str,
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    # 解码URL编码的文件名
    from urllib.parse import unquote
    filename = unquote(filename)
    
    # 构建完整文件路径
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / current_user.department / current_user.username / "results"
    file_path = user_dir / filename
    
    # 返回文件响应
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    
# 地图路由
@router.get("/map")
async def show_map(
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    try:
        # 获取用户密钥
        keys = get_user_key(current_user)
        return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
            <style type="text/css">
            body, html,#allmap {{width: 100%;height: 100%;overflow: hidden;margin:0;font-family:"微软雅黑";}}
            </style>
            <script type="text/javascript" src="//api.map.baidu.com/api?type=webgl&v=1.0&ak={keys[0]}"></script>
            <title>地图展示</title>
        </head>
        <body>
            <div id="allmap"></div>
        </body>
        </html>
        <script type="text/javascript">
            var map = new BMapGL.Map("allmap");
            map.centerAndZoom(new BMapGL.Point(116.404, 39.915), 11);
            map.enableScrollWheelZoom(true);
        </script>
        """)
    except HTTPException as e:
        return HTMLResponse(f"<h1>Error: {e.detail}</h1>")

#地图展示路由
@router.get("/show")
def get_points(
    current_user: User = Depends(get_current_user),
    current_admin: User = Depends(check_permission())
):
    """
    根据用户提供的文件名，从数据库查找路径并提取 points 字段。
    """
    keys = get_user_key(current_user)
    processor = NavigationProcessor(keys)
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / current_user.department / current_user.username / "results"
    point = processor.extract_points_from_results(user_dir,current_user.username)
    point_json = json.dumps(point, ensure_ascii=False)
    try:
        # 获取用户密钥
        keys = get_user_key(current_user)
        return HTMLResponse(f"""
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="utf-8">
            <title>地图展示</title>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
            <meta http-equiv="X-UA-Compatible" content="IE=Edge">
            <style>
            body,
            html,
            #container {{
                overflow: hidden;
                width: 100%;
                height: 100%;
        margin: 0;
        font-family: "微软雅黑";
    }}
    .info {{
        z-index: 999;
        width: auto;
        min-width: 22rem;
        padding: .75rem 1.25rem;
        margin-left: 1.25rem;
        position: fixed;
        top: 1rem;
        background-color: #fff;
        border-radius: .25rem;
        font-size: 14px;
        color: #666;
        box-shadow: 0 2px 6px 0 rgba(27, 142, 236, 0.5);
    }}
    </style>
    <script src="https://api.map.baidu.com/api?v=3.0&ak=HQBeVtGYsoFG7XaLi8xUot3tbHOBEVLm"></script>
</head>
<body>
    <div class = "info">最新版GL地图命名空间为BMapGL, 可按住鼠标右键控制地图旋转、修改倾斜角度。</div>
    <div id="container"></div>
</body>
</html>
<script>
var rawPointData = {point_json};
        var map = new BMap.Map('container');
        map.centerAndZoom(new BMap.Point(109.2907, 22.4166), 17);
        map.enableScrollWheelZoom(true);
        for (var i = 0; i < rawPointData.length; i++) {{
            var coordStr = rawPointData[i];
            var coordPairs = coordStr.split(";");
            var points = [];
            for (var j = 0; j < coordPairs.length; j++) {{
                if (coordPairs[j].trim() === "") continue;
                var lngLat = coordPairs[j].split(",");
                var lng = parseFloat(lngLat[0]);
                var lat = parseFloat(lngLat[1]);
                points.push(new BMap.Point(lng, lat));
            }}
            var polyline = new BMap.Polyline(points, {{
                strokeColor: "blue",
                strokeWeight: 3,
                strokeOpacity: 0.8
            }});
            map.addOverlay(polyline);
             if (points.length >= 2) {{
            var startMarker = new BMap.Marker(points[0]);
            var startLabel = new BMap.Label("起点", {{
                offset: new BMap.Size(20, -10)
            }});
            startMarker.setLabel(startLabel);
            map.addOverlay(startMarker);

            // 终点标记
            var endMarker = new BMap.Marker(points[points.length - 1]);
            var endLabel = new BMap.Label("终点", {{
                offset: new BMap.Size(20, -10)
            }});
            endMarker.setLabel(endLabel);
            map.addOverlay(endMarker);
        }}
        }}
</script>
        """)
    except HTTPException as e:
        return HTMLResponse(f"<h1>Error: {e.detail}</h1>")

# 公司注册路由
@router.post("/register/company")
async def register_company(
    company_data: CompanyCreate,
    db: Session = Depends(get_db)
):
    try:
        # 检查公司名称是否已存在
        existing_company = db.query(Company).filter(Company.name == company_data.name).first()
        if existing_company:
            return {
                "status": 1,
                "msg": "公司注册失败",
                "detail": "公司名称已存在"
            }

        # 创建新公司
        new_company = Company(
            name=company_data.name,
            legal_person=company_data.legal_person,
            contact_phone=company_data.contact_phone
        )
        db.add(new_company)
        db.commit()
        db.refresh(new_company)
        
        return {
            "status": 0,
            "msg": "公司注册成功",
            "data": {
                "id": new_company.id,
                "name": new_company.name,
                "legal_person": new_company.legal_person,
                "contact_phone": new_company.contact_phone
            }
        }
        
    except Exception as e:
        db.rollback()
        return {
            "status": 2,
            "msg": "数据库操作失败",
            "detail": str(e)
        }



########################################用户管理分割线#####################################


# 用户注册申请列表路由
@router.get("/admin/registration-requests")
async def get_registration_requests(
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    try:
        requests = db.query(RegistrationRequest).all()
        return {
            "status": 0,
            "data": [{
                "id": req.id,
                "username": req.username,
                "department": req.department
            } for req in requests]
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "status": 1,
                "msg": "获取申请列表失败",
                "data": {"error": str(e)[:100]}
            }
        )

# 用户注册审核通过路由（带目录创建逻辑）
@router.put("/admin/registration-requests/{request_id}/approve")
async def approve_registration(
    request_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    req = db.query(RegistrationRequest).filter(RegistrationRequest.id == request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="审核请求不存在")

    try:
        # 创建用户记录
        new_user = User(
            username=req.username,
            password=req.password,
            role=1,
            department=req.department
        )
        db.add(new_user)

        # 创建目录结构
        base_dir = Path(__file__).parent / "static/admin"
        user_dir = base_dir / req.department / req.username
        
        try:
            user_dir.mkdir(parents=True, exist_ok=False)
            (user_dir / "uploads").mkdir(exist_ok=True)
            (user_dir / "results").mkdir(exist_ok=True)
        except FileExistsError:
            db.rollback()
            return JSONResponse(
                status_code=400,
                content={
                    "status": 1,
                    "msg": "用户目录已存在",
                    "data": {"path": str(user_dir)}
                }
            )

        # 删除审核记录
        db.delete(req)
        db.commit()
        
        return {"status": 0, "msg": "审核通过，用户目录已创建"}

    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": 2,
                "msg": "服务器内部错误",
                "data": {"error": str(e)[:100]}
            }
        )

# 拒绝用户注册申请路由
@router.delete("/admin/registration-requests/{request_id}")
async def reject_registration(
    request_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    req = db.query(RegistrationRequest).filter(RegistrationRequest.id == request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="审核请求不存在")
    
    try:
        db.delete(req)
        db.commit()
        return {"status": 0, "msg": "申请已拒绝"}
    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": 1,
                "msg": "删除请求失败",
                "data": {"error": str(e)[:100]}
            }
        )


@router.post("/register/company-request")
async def register_company_request(
    company_data: CompanyRegistrationRequestModel,
    db: Session = Depends(get_db),
    current_user: User = Depends(check_permission())
):
    try:
        # 检查公司名称是否已存在
        existing_company = db.query(Company).filter(Company.name == company_data.name).first()
        existing_request = db.query(CompanyRegistrationRequest).filter(
            CompanyRegistrationRequest.name == company_data.name
        ).first()
        
        if existing_company or existing_request:
            return JSONResponse(
                status_code=400,
                content={
                    "status": 1,
                    "msg": "公司名称不可用",
                    "detail": "该公司已注册或正在审核中"
                }
            )

        # 创建审核记录
        new_request = CompanyRegistrationRequest(
            name=company_data.name,
            legal_person=company_data.legal_person,
            contact_phone=company_data.contact_phone
        )
        db.add(new_request)
        db.commit()
        return {
            "status": 0,
            "msg": "公司注册申请已提交",
            "data": company_data.dict()
        }
        
    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": 2,
                "msg": "申请提交失败",
                "detail": str(e)[:100]
            }
        )


# 公司注册申请列表路由
@router.get("/admin/company-requests")
async def get_company_requests(
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    try:
        requests = db.query(CompanyRegistrationRequest).all()
        return {
            "status": 0,
            "data": [{
                "id": req.id,
                "name": req.name,
                "legal_person": req.legal_person,
                "contact_phone": req.contact_phone,
                "create_time": req.create_time.strftime("%Y-%m-%d %H:%M:%S")
            } for req in requests]
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "status": 1,
                "msg": "获取公司申请列表失败",
                "data": {"error": str(e)[:100]}
            }
        )

# 公司审核通过路由
@router.put("/admin/company-requests/{request_id}/approve")
async def approve_company_registration(
    request_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    req = db.query(CompanyRegistrationRequest).get(request_id)
    if not req:
        raise HTTPException(status_code=404, detail="审核请求不存在")

    try:
        # 创建正式公司记录
        new_company = Company(
            name=req.name,
            legal_person=req.legal_person,
            contact_phone=req.contact_phone
        )
        db.add(new_company)
        db.delete(req)
        db.commit()
        return {"status": 0, "msg": "公司注册成功"}
        
    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": 2,
                "msg": "服务器内部错误",
                "data": {"error": str(e)[:100]}
            }
        )

# 公司审核拒绝路由
@router.delete("/admin/company-requests/{request_id}")
async def reject_company_registration(
    request_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(check_permission())
):
    req = db.query(CompanyRegistrationRequest).get(request_id)
    if not req:
        raise HTTPException(status_code=404, detail="审核请求不存在")
    
    try:
        db.delete(req)
        db.commit()
        return {"status": 0, "msg": "公司注册申请已拒绝"}
    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": 1,
                "msg": "删除请求失败",
                "data": {"error": str(e)[:100]}
            }
        )

# 用户管理路由 
@router.get("/users/")
async def read_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(check_permission())
):
    users = db.query(User).all()
    return users


# 新增当前用户路由
@router.get("/users/me")
async def read_current_user(current_user: User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "username": current_user.username,
        "role": current_user.role,
        "department": current_user.department
    }



# 用户更新路由
@router.put("/users/{user_id}")
async def update_user(
    user_id: int,
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(check_permission())
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")

    update_data = user_update.dict(exclude_unset=True)

    # 用户名更新逻辑（保留业务逻辑检查）
    if "username" in update_data:
        existing_user = db.query(User).filter(
            User.username == update_data["username"],
            User.id != user_id
        ).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="用户名已存在")
        user.username = update_data["username"]

    # 保留业务逻辑检查
    if "role" in update_data:
        if user.id == current_user.id:
            raise HTTPException(status_code=403, detail="不能修改自己的权限")
        user.role = int(update_data["role"])


    # 更新所有字段
    for key, value in update_data.items():
        if key not in ["username", "role"]:  # 前面已单独处理
            setattr(user, key, value)
    
    # 添加异常处理确保提交成功
    try:
        db.commit()
        db.refresh(user)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"数据库更新失败: {str(e)}")


    return {
        "message": "用户信息更新成功",
        "updated_data": {  # 返回部分更新后的数据用于验证
            "username": user.username,
            "role": user.role,
            "department": user.department
            }
    }


# 用户删除路由
@router.delete("/users/{user_id}")
async def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(check_permission())
):    
    user = db.query(User).filter(User.id == user_id).first()
    
    # 新增：删除用户目录逻辑
    base_dir = Path(__file__).parent / "static/admin"
    user_dir = base_dir / user.department / user.username
    
    try:
        # 删除用户专属目录（如果存在）
        if user_dir.exists():
            import shutil
            shutil.rmtree(user_dir)
            print(f"已删除用户目录：{user_dir}")
            
        # 保留单位目录（自动保留，无需处理）
    except Exception as e:
        raise HTTPException(500, f"目录删除失败: {str(e)}")
    
    # 原有数据库删除逻辑
    db.delete(user)
    db.commit()
    return {"message": "用户删除成功"}