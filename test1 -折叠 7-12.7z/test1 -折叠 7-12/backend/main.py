from fastapi import FastAPI
from fastapi_amis_admin.admin import AdminSite
from fastapi_amis_admin.admin.settings import Settings
from fastapi.middleware.cors import CORSMiddleware
import logging
import uvicorn
from multiprocessing import Process
from db import init_db, DATABASE_URL
from auth import router as auth_router
from admin.menu import register_menu_system

# 主应用实例（主要用于承载子应用）
app = FastAPI()

def configure_app(app: FastAPI):
    """应用全局配置函数
    Args:
        app: FastAPI应用实例
    """
    # 注册认证路由
    app.include_router(auth_router)
    
    # 配置跨域中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],  # 允许管理员系统访问
        allow_credentials=True,
        allow_methods=["*"],  # 允许所有HTTP方法
        allow_headers=["*"],   # 允许所有请求头
    )

def create_admin_app(config_name: str, port: int):
    """创建并运行管理应用实例
    Args:
        config_name: 系统配置名称（main/root）
        port: 服务监听端口
    """
    # 创建子应用实例
    admin_app = FastAPI()
    
    # 应用全局配置
    configure_app(admin_app)
    
    # 初始化Admin管理后台
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    
    # 注册菜单系统（核心业务逻辑）
    register_menu_system(site, config_name)
    
    # 挂载Admin到子应用
    site.mount_app(admin_app)
    
    # 启动时初始化数据库
    @admin_app.on_event("startup")
    async def startup():
        init_db()
    
    # 启动UVicorn服务器
    uvicorn.run(admin_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    # 配置基础日志格式
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    # 启动双服务进程（用户系统 + 管理员系统）
    Process(target=create_admin_app, args=("main", 8000)).start()   # 普通用户系统
    Process(target=create_admin_app, args=("root", 9000)).start()   # 管理员后台系统