from sqlalchemy import Column, Integer, String, create_engine, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from sqlalchemy import DateTime, ForeignKey

# 数据库连接字符串
DATABASE_URL = "sqlite:///./test.db"  

# 创建基础类
Base = declarative_base()

# 用户表模型
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True) 
    password = Column(String) 
    role = Column(Integer, default=1)
    department = Column(String(100))
    magic_number = Column(Integer, default=0)

# 公司表模型
class Company(Base):
    __tablename__ = "companies"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True)
    legal_person = Column(String(50))
    contact_phone = Column(String(20))

# 用户注册申请表模型
class RegistrationRequest(Base):
    __tablename__ = "registration_requests"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    password = Column(String)
    department = Column(String(100))
    create_time = Column(DateTime, default=datetime.utcnow)

class CompanyRegistrationRequest(Base):
    __tablename__ = "company_registration_requests"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True)
    legal_person = Column(String(50))
    contact_phone = Column(String(20))
    create_time = Column(DateTime, default=datetime.utcnow)


# 数据库引擎和会话
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()