from abc import ABC, abstractmethod
from typing import List, Dict, Tuple
import pandas as pd
import requests
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import queue
import math
from pathlib import Path

class AbstractMapService(ABC):
    """地图服务抽象基类"""
    @abstractmethod
    def get_route(self, origin: Tuple[float, float],
                 destination: Tuple[float, float]) -> Dict:
        pass


class BaiduMapService(AbstractMapService):
    """百度地图服务实现（支持密钥自动轮换）"""
    def __init__(self, api_keys: List[str]):
        self.base_url = "https://api.map.baidu.com/directionlite/v1/driving"
        self.geocode_url = "https://api.map.baidu.com/geocoding/v3/"
        self.api_keys = api_keys
        self.current_key_index = 0

    def get_route(self, origin: Tuple[float, float],
                 destination: Tuple[float, float]) -> Dict:
        attempt_count = 0  # 记录尝试次数
        
        while attempt_count < len(self.api_keys):
            params = {
                "origin": f"{origin[0]},{origin[1]}",
                "destination": f"{destination[0]},{destination[1]}",
                "ak": self.api_keys[self.current_key_index],
                "coord_type": "gcj02",
                "ret_coordtype": "gcj02"
            }

            try:
                resp = requests.get(self.base_url, params=params)
                data = resp.json()
                
                if data.get("status") == 0:
                    return {
                        "distance": data["result"]["routes"][0]["distance"],
                        "duration": data["result"]["routes"][0]["duration"],
                        "points": ";".join(step.get("path") for step in data["result"]["routes"][0]["steps"])
                    }
                elif data.get("status") == 302:
                    print(f"密钥 {self.api_keys[self.current_key_index]} 配额不足，尝试下一个...")
                    self._rotate_key()
                    attempt_count += 1
                else:
                    print(f"API请求失败[{self.current_key_index}]: {data.get('message')}")
                    return {"error": data.get("message", "Unknown error")}

            except requests.exceptions.RequestException as e:
                print(f"网络请求失败: {str(e)}")
                return {"error": f"网络请求失败: {str(e)}"}
            except json.JSONDecodeError as e:
                print(f"JSON解析失败: {str(e)}")
                return {"error": f"JSON解析失败: {str(e)}"}
        


    def geocode_address(self, address: str) -> Tuple[float, float]:
        attempt_count = 0
        
        while attempt_count < len(self.api_keys):
            params = {
                "address": address,
                "ak": self.api_keys[self.current_key_index],
                "output": "json",
                "ret_coordtype": "gcj02"
            }
            
            try:
                resp = requests.get(self.geocode_url, params=params)
                data = resp.json()
                
                if data.get("status") == 0:
                    location = data["result"]["location"]
                    return location["lat"], location["lng"]
                elif data.get("status") == 302:
                    print(f"密钥 {self.api_keys[self.current_key_index]} 地理编码配额不足")
                    self._rotate_key()
                    attempt_count += 1
                else:
                    print(f"地理编码失败: {data.get('message')}")
                    return None, None
                    
            except Exception as e:
                print(f"请求异常: {str(e)}")
                return None, None
        
        print("所有地理编码密钥均已耗尽！")
        return None, None

    def _rotate_key(self):
        """轮换到下一个可用密钥"""
        self.current_key_index = (self.current_key_index + 1) % len(self.api_keys)
        print(f"切换至密钥索引：{self.current_key_index}")


class NavigationProcessor:
    """导航处理核心类"""
    def __init__(self, api_keys: List[str]):
        self.service = BaiduMapService(api_keys)
        self.results = queue.Queue()  # 使用线程安全的队列
        self.lock = Lock()  # 用于保护共享资源

    def process_excel(self, 
                      file_path: str,
                      input_sheet_name: str = "Sheet1",
                      output_sheet_prefix: str = "Results",
                      num_chunks: int = 1):
        try:
            coordinates = self.read_excel(file_path, input_sheet_name)
            print("解析后的坐标数据：")
            print(coordinates)

            # 计算总任务数和分块数
            total_tasks = len(coordinates) * (len(coordinates) - 1)
            tasks_per_chunk = math.ceil(total_tasks / num_chunks)  # 计算每块任务数
            print(f"总任务数: {total_tasks}, 分块数: {num_chunks}，每块约 {tasks_per_chunk} 个任务")

            # 分块处理
            for chunk_index in range(num_chunks):
                print(f"\n处理第 {chunk_index + 1} 块数据...")
                self.results = queue.Queue()
                self.process_routes(coordinates, chunk_index, tasks_per_chunk)
                self.save_to_excel(file_path, f"{output_sheet_prefix}_chunk_{chunk_index + 1}")
        except Exception as e:
            print(f"处理 Excel 文件出错: {e}")

    def read_excel(self, file_path: str, sheet_name: str = "Sheet1") -> pd.DataFrame:
        """读取 Excel 坐标数据"""
        df = pd.read_excel(file_path, sheet_name=sheet_name)

        def parse_coord(coord_str):
        # 转换为字符串并清理换行符
            raw_str = str(coord_str).strip().replace('\n', ' ')
            
            # 尝试识别JSON格式
            if raw_str.startswith(('{', '[')):  # 初步判断可能是JSON
                try:
                    data = json.loads(raw_str)
                    if isinstance(data, dict) and 'lat' in data and 'lng' in data:
                        print(f"成功解析JSON坐标：{data}")
                        return data['lat'], data['lng']
                except json.JSONDecodeError:
                    pass  # 不是有效JSON则继续处理
            
            # 作为地址进行地理编码
            print(f"尝试解析地址：{raw_str}")
            lat, lng = self.service.geocode_address(raw_str)
            if lat and lng:
                return lat, lng
            print(f"地址解析失败：{raw_str}")
            return None, None

        if df.columns.ndim == 1:
            df[["latitude", "longitude"]] = df[df.columns[0]].apply(lambda x: pd.Series(parse_coord(x)))
            return df.dropna()  # 删除解析失败的行
        else:
            return df[["latitude", "longitude"]].dropna()  # 删除解析失败的行

    def process_route(self, origin: Tuple[float, float], dest: Tuple[float, float]) -> Dict:
        result = {
            "start_lat": origin[0],
            "start_lon": origin[1],
            "end_lat": dest[0],
            "end_lon": dest[1]
        }
        route_data = self.service.get_route(origin, dest)
        if "error" in route_data:
            result.update(route_data)
        else:
            result.update({
                "distance": route_data["distance"],
                "duration": route_data["duration"],
                "points": route_data["points"]
            })
        return result

    def process_routes(self, coordinates: pd.DataFrame, chunk_index: int, chunk_size: int) -> None:
        """处理路径规划"""
        total = len(coordinates) * (len(coordinates) - 1)  # 总的任务数
        start_task = chunk_index * chunk_size  # 当前块的起始任务索引
        end_task = min((chunk_index + 1) * chunk_size, total)  # 当前块的结束任务索引
        completed = 0  # 已完成的任务数
        last_percentage_printed = 0  # 上次打印百分比

        futures = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            task_count = 0
            for i in range(len(coordinates)):
                for j in range(len(coordinates)):
                    if i == j:
                        continue
                    if task_count < start_task:
                        task_count += 1
                        continue
                    if task_count >= end_task:
                        break

                    origin = (coordinates.iloc[i]['latitude'], coordinates.iloc[i]['longitude'])
                    dest = (coordinates.iloc[j]['latitude'], coordinates.iloc[j]['longitude'])
                    futures.append(executor.submit(self.process_route, origin, dest))
                    task_count += 1

            for future in as_completed(futures):
                try:
                    result = future.result()
                    self.results.put(result)  # 使用队列存储结果
                    completed += 1
                    percentage_completed = (completed / (end_task - start_task)) * 100

                    # 每完成 0.1% 输出一次
                    if int(percentage_completed * 10) > int(last_percentage_printed * 10):
                        print(f"已完成: {percentage_completed:.2f}%")
                        last_percentage_printed = percentage_completed
                except Exception as e:
                    print(f"任务出错: {e}")

    def save_to_excel(self, file_path: str, output_sheet: str = "Results") -> None:
        """保存结果到 Excel"""
        results_list = []
        while not self.results.empty():
            results_list.append(self.results.get())

        # 解析原始文件路径
        original_path = Path(file_path)
        results_dir = original_path.parent.parent / "results"
        output_filename = f"{original_path.stem}_{output_sheet}.xlsx"
        
        # 完整输出路径
        output_file_path = results_dir / output_filename
        
        # 保存到新路径
        df = pd.DataFrame(results_list)
        with pd.ExcelWriter(output_file_path, mode='w') as writer:
            df.to_excel(writer, sheet_name=output_sheet, index=False)
        
        print(f"结果已保存到: {output_file_path}")


    def extract_points_from_results(self, file_path: str,username:str, sheet_prefix: str = "Results") -> List[str]:
        
            original_path = Path(file_path)
            results_dir = original_path.parent.parent/ username / "results"

            if not results_dir.exists():
                print("结果文件夹不存在。")
                return []

        # 查找所有匹配文件，如 xxx_Results_chunk_1.xlsx 等
            result_files = sorted(results_dir.glob(f"{username}_{sheet_prefix}_chunk_*.xlsx"))
            print(result_files)
            if not result_files:
                print("未找到任何结果文件。")
                return []

            all_points = []

            for file in result_files:
                try:
                    df = pd.read_excel(file)
                    if "points" in df.columns:
                        points_list = df["points"].dropna().tolist()
                        all_points.extend(points_list)
                        print(f"已从 {file.name} 提取 {len(points_list)} 条路径。")
                    else:
                        print(f"文件 {file.name} 中无 'points' 字段。")
                except Exception as e:
                    print(f"读取文件 {file.name} 失败: {e}")

            print(f"总共提取 {len(all_points)} 条路径数据。")
            return all_points    





    