from pydantic import BaseModel, Field

# Create your schemas here.

