from fastapi import FastAPI
from fastapi_amis_admin.admin import AdminSite
from fastapi_amis_admin.admin.settings import Settings
from fastapi.middleware.cors import CORSMiddleware
import logging
import uvicorn
from multiprocessing import Process
from db import init_db, DATABASE_URL
from auth import router as auth_router
from admin.menu import register_menu_system

app = FastAPI()

def configure_app(app: FastAPI):
    app.include_router(auth_router)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

def create_admin_app(config_name: str, port: int):
    admin_app = FastAPI()
    configure_app(admin_app)
    
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    register_menu_system(site, config_name)
    
    site.mount_app(admin_app)
    
    @admin_app.on_event("startup")
    async def startup():
        init_db()
    
    uvicorn.run(admin_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    Process(target=create_admin_app, args=("main", 8000)).start()
    Process(target=create_admin_app, args=("root", 9000)).start()