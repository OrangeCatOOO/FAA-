from fastapi import Depends
from fastapi_amis_admin.admin import AdminSite, AdminApp, PageAdmin
from fastapi_amis_admin.amis.components import PageSchema, Page
from .config import load_system_config
from .pages import create_page_admin
from auth import check_permission  
from pathlib import Path
import json
import logging

def create_child_page(child_config, parent_name, index):
    """创建子页面类（带权限控制）"""
    class ChildPage(PageAdmin):
        page_schema = child_config.get('page_schema') or child_config['name']
        page_path = f"/external/{parent_name.lower()}_{index}"
        
        def __init__(self, admin):
            super().__init__(admin)
            self._config = child_config
        
        @property
        def page(self):
            try:
                if self._config.get("path"):
                    config_path = (
                        Path(__file__).parent.parent 
                        / "config" / "pages" 
                        / f"{self._config['path']}.json"
                    )
                    with open(config_path, "r", encoding="utf-8") as f:
                        return Page.parse_obj(json.load(f))
            except Exception as e:
                logging.error(f"页面加载失败: {str(e)}")
                return Page.parse_obj({"type": "page", "body": f"加载失败: {str(e)}"})
    
    if child_config.get("permission") is not None:
        ChildPage.dependencies = [Depends(check_permission)]
    
    ChildPage.__name__ = f"ChildPage_{parent_name}_{index}"
    return ChildPage

def register_menu_system(site: AdminSite, config_name: str):
    """通用菜单注册系统"""
    systems = load_system_config(config_name)
    
    for system in systems:
        if "children" in system:
            class ParentPage(AdminApp):
                page_schema = PageSchema(label=system['name'], icon="fa fa-folder")
                
                def __init__(self, app):
                    super().__init__(app)
                    for idx, child in enumerate(system["children"]):
                        self.register_admin(create_child_page(child, system['name'], idx))
            
            site.register_admin(ParentPage)