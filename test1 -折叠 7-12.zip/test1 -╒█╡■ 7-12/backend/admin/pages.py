from pathlib import Path
import json
from fastapi_amis_admin.admin import PageAdmin
from fastapi_amis_admin.amis.components import Page

def create_page_admin(config_file: str):
    """创建动态页面管理类"""
    class DynamicPageAdmin(PageAdmin):
        def __init__(self, admin):
            super().__init__(admin)
            config_path = Path(__file__).parent.parent / "config" / "pages" / f"{config_file}.json"
            with open(config_path, "r", encoding="utf-8") as f:
                self._page_config = json.load(f)
        
        @property
        def page(self):
            return Page.parse_obj(self._page_config)
    
    return DynamicPageAdmin