from pathlib import Path
import json
import logging
from typing import List, Dict

def load_system_config(config_name: str) -> List[Dict]:
    """加载系统菜单配置"""
    config_file = "user_system.json" if config_name == "main" else "admin_system.json"
    config_path = Path(__file__).parent.parent / "config" / "menu" / config_file
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)["menu"]
    except Exception as e:
        logging.error(f"加载系统配置失败: {str(e)}")
        return []