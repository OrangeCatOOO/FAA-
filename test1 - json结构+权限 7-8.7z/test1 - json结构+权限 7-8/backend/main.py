from fastapi import FastAPI, Depends
from fastapi_amis_admin import admin
from fastapi_amis_admin.admin import AdminSite, PageAdmin
from fastapi_amis_admin.admin.settings import Settings
from fastapi_amis_admin.amis.components import Page
from fastapi.middleware.cors import CORSMiddleware
from auth import router as auth_router, check_permission
from db import init_db, DATABASE_URL
from importlib import import_module
from pathlib import Path
import json
import logging
import uvicorn
from multiprocessing import Process

app = FastAPI()

def configure_app(app: FastAPI):
    app.include_router(auth_router)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:9000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

def create_page_admin(config_file: str, page_path: str = None, page_schema: str = None):
#动态页面创建工厂函数
    class DynamicPageAdmin(PageAdmin):
        def __init__(self, admin: AdminSite):
            super().__init__(admin)
            config_path = Path(__file__).parent / "config" / "pages" / f"{config_file}.json"
            with open(config_path, "r", encoding="utf-8") as f:
                self._page_config = json.load(f)
        
        @property
        def page(self):
            return Page.parse_obj(self._page_config)

    # 设置类属性
    if page_path:
        DynamicPageAdmin.page_path = page_path
    if page_schema:
        DynamicPageAdmin.page_schema = page_schema
    
    return DynamicPageAdmin

def load_pages(config_path: str) -> list:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)["pages"]

def register_pages(site: AdminSite, pages_config: list):
    for page_config in pages_config:
        # 动态创建页面类
        page_class = create_page_admin(
            config_file=page_config["config_file"],
            page_path=page_config.get("page_path"),
            page_schema=page_config.get("page_schema")
        )
        
        # 添加权限依赖
        dependencies = []
        if page_config.get("permission") is not None:
            # 改为直接使用check_permission依赖
            dependencies.append(Depends(check_permission))
        
        # 注册管理类
        site.register_admin(
            type(
                f"{page_config['config_file']}Admin",
                (page_class,),
                {"dependencies": dependencies}
            )
        )

def create_admin_app(config_name: str, port: int):
    admin_app = FastAPI()
    configure_app(admin_app)
    
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    site.unregister_admin(admin.HomeAdmin)
    
    config_path = Path(__file__).parent / "config" / "menu" / f"{config_name}_config.json"
    pages_config = load_pages(config_path)
    register_pages(site, pages_config)
    
    site.mount_app(admin_app)
    
    @admin_app.on_event("startup")
    async def startup():
        init_db()
    
    uvicorn.run(admin_app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    Process(target=create_admin_app, args=("main", 8000)).start()
    Process(target=create_admin_app, args=("root", 9000)).start()