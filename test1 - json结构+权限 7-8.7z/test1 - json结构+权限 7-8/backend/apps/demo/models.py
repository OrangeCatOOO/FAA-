from typing import Optional
from sqlmodel import SQLModel
from fastapi_amis_admin import amis
from fastapi_amis_admin.models import Field
from sqlmodel import SQLModel, Field
from sqlalchemy.types import DOUBLE_PRECISION

class User(SQLModel, table=True):
    id: int = Field(primary_key=True, title="用户ID")
    name: str = Field(max_length=50, unique=True, title="用户名")
    email: str = Field(unique=True, title="邮箱")

# Create your models here.

# class Category(SQLModel, table=True):
#     __tablename__ = 'blog_category'
#     id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
#     name: str = Field(
#         title='Category Name',
#         unique=True,
#         index=True,
#         nullable=False,
#     )
#     description: str = Field(default='', title='Description', amis_form_item=amis.Textarea())
#     is_active: bool = Field(False, title='Is Active')
