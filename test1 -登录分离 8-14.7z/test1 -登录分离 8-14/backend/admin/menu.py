from fastapi import Depends
from fastapi_amis_admin.admin import AdminSite, AdminApp, PageAdmin
from fastapi_amis_admin.amis.components import PageSchema, Page
from .config import load_system_config
from .pages import create_page_admin
from auth import check_permission  
from pathlib import Path
import json
import logging

def create_child_page(child_config, parent_name, index):
    """创建带权限控制的子页面类"""
    class ChildPage(PageAdmin):
        # 添加父级哈希值确保路径唯一性
        page_schema = child_config['name']

        def __init__(self, admin):
            super().__init__(admin)
            self._config = child_config

        @property
        def page(self):
            try:
                if self._config.get("path"):
                    config_path = (
                        Path(__file__).parent.parent 
                        / "config" / "pages" 
                        / f"{self._config['path']}.json"
                    )
                    if not config_path.exists():
                        raise FileNotFoundError(f"配置文件不存在: {config_path}")
                    with open(config_path, "r", encoding="utf-8") as f:
                        return Page.parse_obj(json.load(f))
            except Exception as e:
                logging.error(f"页面加载失败: {str(e)}")
                return Page.parse_obj({"type": "page", "body": f"加载失败: {str(e)}"})

    if child_config.get("permission") is not None:
        ChildPage.dependencies = [Depends(check_permission)]
    
    # 使用哈希值生成唯一类名
    ChildPage.__name__ = f"ChildPage_{abs(hash(parent_name))}_{index}"
    return ChildPage

def register_menu_system(site: AdminSite, config_name: str):
    """注册菜单系统核心逻辑
    Args:
        site: AdminSite实例
        config_name: 配置名称（main-普通用户系统 / root-管理员系统）
    """
    systems = load_system_config(config_name)
    
    # 处理平级页面
    for system in systems:
        if system.get("is_flat"):
            page_class = create_child_page(system, "system", 0)
            site.register_admin(page_class)
            continue  # 跳过后续处理
    
    # 处理嵌套菜单
    def create_nested_menu(menu_config, parent_app=None):
        class ParentPage(AdminApp):
            __name__ = f"ParentPage_{menu_config['name']}"
            page_schema = PageSchema(
                label=menu_config['name'],
                icon="fa fa-folder"
            )
            
            def __init__(self, app):
                super().__init__(app)
                # 注册所有子页面
                for idx, child in enumerate(menu_config.get("children", [])):
                    # 递归处理嵌套菜单
                    if "children" in child:
                        create_nested_menu(child, self)
                    else:
                        self.register_admin(create_child_page(child, menu_config['name'], idx))
        
        # 注册到父级或根站点
        if parent_app:
            parent_app.register_admin(ParentPage)
        else:
            site.register_admin(ParentPage)
    
    # 创建嵌套菜单结构
    for system in systems:
        if "children" in system and not system.get("is_flat"):
            create_nested_menu(system)