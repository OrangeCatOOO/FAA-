from pathlib import Path
import json
import logging
from typing import List, Dict

def load_system_config(config_name: str) -> List[Dict]:
    """加载系统菜单配置"""
    # 根据配置名称选择对应的JSON文件
    if config_name == "main":
        config_file = "user_system.json"
    elif config_name == "admin":
        config_file = "admin_system.json"
    elif config_name == "auth":
        config_file = "auth_system.json"
    else:
        config_file = "user_system.json"
        logging.warning(f"未知的配置名称: {config_name}, 使用默认配置")
    
    config_path = Path(__file__).parent.parent / "config" / "menu" / config_file
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)["menu"]
    except Exception as e:
        logging.error(f"加载系统配置失败: {str(e)}")
        return []