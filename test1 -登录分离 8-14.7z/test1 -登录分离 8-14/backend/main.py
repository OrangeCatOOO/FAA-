from fastapi import FastAPI
from fastapi_amis_admin.admin import AdminSite
from fastapi_amis_admin.admin.settings import Settings
from fastapi.middleware.cors import CORSMiddleware
import logging
import uvicorn
from multiprocessing import Process
from db import init_db, DATABASE_URL
from auth_router import router as auth_router
from auth import router as auth_api_router
from admin.menu import register_menu_system

# 服务配置列表
SERVICES = [
    {"name": "用户系统", "config": "main", "port": 8000, "allow_origins": ["http://127.0.0.1:8000", "http://127.0.0.1:9000"]},
    #用户系统需要与管理员系统交互，例如管理员可能需要查看/管理用户数据
    {"name": "管理员系统", "config": "admin", "port": 9000, "allow_origins": ["http://127.0.0.1:8000", "http://127.0.0.1:9000"]},
    {"name": "认证系统", "config": "auth", "port": 7000, "allow_origins": ["http://127.0.0.1:8000", "http://127.0.0.1:9000", "http://127.0.0.1:7000"]},
]

def configure_app(app: FastAPI, allow_origins: list):
    """应用全局配置函数"""
    # 注册认证路由
    app.include_router(auth_router)
    app.include_router(auth_api_router)
    
    # 配置跨域中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )


def create_admin_app(config_name: str, port: int, allow_origins: list):
    """创建并运行管理应用实例"""
    # 创建子应用实例
    admin_app = FastAPI(title=f"{config_name}系统")
    
    # 应用全局配置
    configure_app(admin_app, allow_origins)
    
    # 初始化Admin管理后台
    site = AdminSite(settings=Settings(database_url=DATABASE_URL))
    
    # 注册菜单系统（核心业务逻辑）
    register_menu_system(site, config_name)
    
    # 挂载Admin到子应用
    site.mount_app(admin_app)
    
    # 启动时初始化数据库
    @admin_app.on_event("startup")
    async def startup():
        init_db()
        logging.info(f"{config_name}系统启动成功，监听端口: {port}")
    
    # 启动UVicorn服务器
    uvicorn.run(admin_app, host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    # 配置基础日志格式
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    logger = logging.getLogger(__name__)
    logger.info("Starting servers...")
    
    # 启动所有服务进程
    processes = []
    for service in SERVICES:
        p = Process(
            target=create_admin_app,
            args=(service["config"], service["port"], service["allow_origins"]),
            name=service["name"]
        )
        processes.append(p)
        p.start()
    
    # 等待所有进程完成
    for p in processes:
        p.join()