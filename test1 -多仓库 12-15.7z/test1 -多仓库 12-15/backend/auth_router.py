from fastapi import APIRouter, Depends, HTTPException, status, Request, Response, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import jwt, uuid, secrets, os
from pathlib import Path
from passlib.context import CryptContext
from typing import List, Tuple, Optional

from db import User, SessionLocal, RegistrationRequest
from model import UserLogin, UserCreate, RegistrationRequestInDB

# 创建路由实例
router = APIRouter()

# JWT 配置
SECRET_KEY = os.getenv("JWT_SECRET", "dev_secret_placeholder")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# 密码哈希上下文
pwd_context = CryptContext(schemes=["bcrypt", "django_pbkdf2_sha256"], deprecated="auto")

# 数据库依赖
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()







# 核心认证功能

def get_password_hash(password: str):
    return pwd_context.hash(password)

async def get_token_from_cookie(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="需要重新登录",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return token



def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(
    token: str = Depends(get_token_from_cookie),
    db: Session = Depends(get_db)
):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="需要重新登录",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if not username:
            raise credentials_exception
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="登录已过期")
    except jwt.InvalidTokenError:
        raise credentials_exception

    user = db.query(User).filter(User.username == username).first()
    return user or credentials_exception


# 添加用户信息接口
@router.get("/users/me")
async def read_users_me(current_user: User = Depends(get_current_user)):
    return {
        "username": current_user.username,
        "role": current_user.role,
        "department": current_user.department
    }



# 登录路由
@router.post("/login")
async def login(
    response: Response,
    user_data: UserLogin, 
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.username == user_data.username).first()
    
    if not user:
        raise HTTPException(401, "用户名或密码错误")

    try:
        if not pwd_context.verify(user_data.password, user.password):
            raise HTTPException(401, "用户名或密码错误")
    except Exception as e:
        raise HTTPException(500, f"密码验证异常: {str(e)}")

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=access_token_expires
    )
    
    new_magic = secrets.randbelow(1000000) + 1
    
    try:
        user.magic_number = new_magic
        db.commit()
        db.refresh(user)
    except Exception as e:
        db.rollback()
        raise HTTPException(500, detail=f"数据库更新失败: {str(e)}")

    cookie_params = {
        "max_age": access_token_expires.seconds,
        "httponly": True,
        "samesite": "Lax",
        "secure": True,
        "path": "/"
    }
    
    response.set_cookie(key="access_token", value=access_token, **cookie_params)
    response.set_cookie(key="magic_number", value=str(new_magic), **cookie_params)
    
    return {
        "message": "登录成功",
        "username": user.username,
        "role": user.role
    }

# 注册路由
@router.post("/register")
async def register(
    request: RegistrationRequestInDB, 
    db: Session = Depends(get_db)
):
    existing_user = db.query(User).filter(User.username == request.username).first()
    existing_request = db.query(RegistrationRequest).filter(RegistrationRequest.username == request.username).first()
    
    if existing_user or existing_request:
        return {
            "status": 1,
            "msg": "用户名不可用",
            "detail": "该用户名已被注册或正在审核中"
        }

    new_request = RegistrationRequest(
        username=request.username,
        password=pwd_context.hash(request.password, scheme="bcrypt"),
        department=request.department
    )
    db.add(new_request)
    db.commit()
    
    return {
        "status": 0,
        "msg": "注册申请已提交",
        "data": {
            "username": request.username,
            "department": request.department
        }
    }

# 注销路由
@router.post("/logout")
def user_logout(response: Response):
    response.delete_cookie("access_token")
    response.delete_cookie("magic_number")
    return {"message": "退出成功"}
