from fastapi_amis_admin import amis, admin
from fastapi_amis_admin.admin import AdminApp
from fastapi_amis_admin.admin import admin
from .models import User  # 从当前目录导入

@admin.register_admin
class UserAdmin(admin.ModelAdmin):
    model = User
    page_schema = "用户管理"
    list_fields = ["id", "name", "email"]
# from .models import Category


class DemoApp(admin.AdminApp):
    page_schema = amis.PageSchema(label='Demo', icon='fa fa-bolt')
    router_prefix = '/demo'

    def __init__(self, app: "AdminApp"):
        super().__init__(app)
        # self.register_admin(CategoryAdmin)


# Register your models here.

# class CategoryAdmin(admin.ModelAdmin):
#     page_schema = amis.PageSchema(label='Category', icon='fa fa-folder')
#     model = Category
#     search_fields = [Category.name]
